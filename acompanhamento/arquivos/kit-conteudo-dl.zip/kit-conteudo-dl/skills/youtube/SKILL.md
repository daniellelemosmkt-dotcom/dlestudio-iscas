---
name: youtube
description: "Cria estratégias e roteiros de YouTube de alta performance pelo Método Dani. Use sempre que o usuário pedir roteiro para YouTube, vídeo longo, conteúdo para canal, vídeo de 5 a 10 minutos, pauta de YouTube, ou variações como \"subir um vídeo\", \"gravar pra YouTube\", \"fazer um roteiro\", \"criar conteúdo para canal\", ou pedir retenção, alcance e crescimento de inscritos. Antes de perguntar qualquer coisa, lê automaticamente arquivos de estratégia do projeto (estrategia.md, Estrategia_YouTube*.docx, briefing.md) — e só pergunta o que faltar, normalmente apenas o tema do vídeo. Mantém sua própria frente de tendências de canal (vidIQ, via Claude em Chrome, quando disponível), sem depender de outra skill rodar antes. Entrega quatro blocos: (1) benchmark de títulos de maior performance no nicho e termos mais buscados; (2) roteiro AIDA para vídeo de 5 a 10 min com técnicas de retenção; (3) descrição otimizada para SEO com timestamps, palavras-chave, hashtags e CTAs; (4) cortes para Reels/Shorts e sugestão de thumbnail."
---

# Método Dani — Roteiros de YouTube de Alta Performance

## Princípio central

Um roteiro de YouTube ganha ou perde nos primeiros 30 segundos. Depois disso, ganha ou perde no encadeamento. Cada bloco do vídeo precisa entregar algo de valor concreto e abrir um loop para o bloco seguinte. Roteiro genérico não retém. Roteiro com hook fraco não alcança. Roteiro sem CTA explícito não converte. O Método Dani aplica AIDA (Atenção, Interesse, Desejo, Ação) com estratégias específicas de retenção da plataforma para que o vídeo cumpra três objetivos simultâneos: ser assistido até o fim, ser empurrado pelo algoritmo e gerar inscrição.

---

## Etapa 1: Leitura de contexto do projeto

Antes de perguntar qualquer coisa, faça uma varredura silenciosa para entender o contexto do cliente. Siga esta ordem:

**Passo 1 — Procurar documento de estratégia**
Tente localizar arquivos com nomes como `estrategia.md`, `Estrategia_YouTube*.docx`, `briefing.md`, `cliente.md`, `perfil.md` ou qualquer arquivo `.md`, `.txt`, `.docx` que pareça documento de estratégia ou briefing. Use Glob ou Read para isso. Para arquivos `.docx`, use a Read tool.

**Passo 2 — Se não houver arquivo de estratégia**
Leia os demais arquivos disponíveis na pasta do projeto que possam conter informações sobre o cliente, público-alvo, pilares de conteúdo, tom ou objetivo.

**Passo 3 — Se não houver pasta de projeto montada**
Leia o histórico da conversa atual para identificar o que já foi mencionado sobre o cliente.

**Passo 4 — Montar o briefing interno**
Com base no que foi encontrado, monte internamente (sem exibir ao usuário) um briefing com:
- Especialidade ou nicho do cliente
- Público-alvo
- Pilares de conteúdo do canal
- Tom de voz
- Objetivo estratégico do canal
- Restrições ou contexto específico
- Existência de arquivos de estratégia já produzidos (KPIs, cronograma, roteiros anteriores)

**Passo 5 — Perguntar apenas o que falta**
Se o briefing estiver completo, a única pergunta necessária é o tema do vídeo. Se faltar algum dado essencial, pergunte só o que falta. Nunca repita perguntas cujas respostas já estão no contexto.

---

## Etapa 2: Pesquisa de benchmark e palavras-chave

Esta etapa é obrigatória antes de escrever o roteiro. Sem ela, o vídeo nasce no vácuo.

### 2.1 — Pesquisa de títulos de alta performance no nicho

Use a ferramenta WebSearch para localizar vídeos do mesmo tema (ou tema adjacente) com alto número de visualizações. A query de busca deve combinar:

- O tema central do vídeo (ex: "como emagrecer", "tireoide hipotireoidismo")
- O nicho ou especialidade do cliente (ex: "nutrólogo", "endocrinologista", "fisioterapeuta")
- Termos auxiliares de busca: "youtube mais visto", "milhões de visualizações", "viral"

Recolha pelo menos 6 a 10 títulos que estão performando bem no nicho. Para cada título capturado, anote:
- Título exato
- Faixa estimada de visualizações
- Padrão estrutural (uso de "Como", número, pergunta, palavra em caixa alta, objeção, paradoxo)

Esses padrões são a engenharia que vai informar a escolha do título do roteiro.

### 2.2 — Pesquisa de termos mais buscados no YouTube

Use WebSearch para identificar:
- O que as pessoas digitam no YouTube quando querem informação sobre o tema
- Variações da palavra-chave (long tail)
- Perguntas frequentes relacionadas ao tema
- Sugestões de auto-complete do YouTube e do Google (queries do tipo "como [tema]", "por que [tema]", "[tema] sintomas", "[tema] tratamento")

Liste 10 a 15 termos relacionados ordenados por probabilidade de busca. Esses termos serão usados em três lugares: na escolha do título, na descrição (para SEO) e nos cortes para Reels/Shorts.

### 2.2B — Frente própria de tendências de nicho e canais de referência (vidIQ)

Além da pesquisa de títulos (2.1) e termos buscados (2.2), esta skill mantém sua própria frente de tendências de YouTube, sem depender de rodar outra skill antes dela. Quando o Claude em Chrome estiver disponível, use uma extensão de análise de canal como o vidIQ para identificar: canais de referência ativos no nicho, vídeos que estão ganhando tração agora (não só os consagrados de sempre) e os termos ou tags que canais em crescimento rápido estão usando neste momento.

Isso mantém a pesquisa de tendências de YouTube inteira dentro da própria skill-youtube — uma tarefa, uma skill, sem precisar rodar uma varredura externa antes de escrever o roteiro.

Se o Claude em Chrome ou uma extensão de análise de canal não estiverem disponíveis, siga só com WebSearch (2.1 e 2.2) e avise na entrega que a camada de canais em ascensão não pôde ser checada.

### 2.3 — Critério de escolha do título do vídeo

Aplique os padrões observados no benchmark. Bons títulos de YouTube no contexto de saúde, performance e autoridade técnica geralmente combinam:

- Abertura com "Como", "Por que", "O que" ou número (listicle)
- Uma palavra em CAIXA ALTA para criar contraste visual na thumb
- Uma objeção, paradoxo ou promessa de revelação ("sem remédio", "que ninguém te conta", "antes de começar")
- No máximo 60 caracteres
- A palavra-chave principal (a que mais aparece nas buscas) próxima do início

Antes de escrever o roteiro, decida o título. O título guia o roteiro, não o contrário.

---

## Etapa 3: Estrutura AIDA aplicada ao YouTube de 5 a 10 minutos

O roteiro segue quatro fases (AIDA), distribuídas em blocos cronológicos. A duração de cada bloco se adapta à duração total do vídeo. O default são vídeos de 5 a 7 minutos. Se o tema exigir, expandir até 10 minutos.

### A — Atenção (0:00 a 0:30)

A função do bloco é fazer a pessoa não fechar. Conteúdo:
- Frase de impacto ou pergunta direta nos primeiros 5 segundos
- Identificação imediata da dor ou da curiosidade
- Promessa explícita do que o vídeo entrega
- Mini apresentação (3 a 5 segundos no máximo, integrada ao texto, nunca como bloco separado de "oi pessoal, sejam bem-vindos ao meu canal")
- Open loop: anunciar algo específico que será revelado mais à frente para que o espectador fique até lá

Sem vinheta longa, sem agradecimento, sem "antes de começar deixa o like". Esses elementos derrubam retenção.

### I — Interesse (0:30 a 1:30 ou 0:30 a 2:00)

A função do bloco é fazer a pessoa entender por que isso importa pra ela. Conteúdo:
- Contextualização rápida do problema (por que ele acontece)
- Analogia simples que traduz a complexidade técnica
- Validação da dor (sem condescendência, sem dramatização excessiva)
- Construção de autoridade implícita: o conteúdo já mostra que quem fala sabe do que está falando
- Reforço do open loop: lembrar que algo importante vem mais adiante

### D — Desejo (1:30 a 4:00 em vídeos de 5min, ou até 7:30 em vídeos de 10min)

A função do bloco é entregar o valor central e construir o desejo de mudança. Conteúdo:
- O erro mais comum que as pessoas cometem com esse tema (gera engajamento e comentário)
- Os 3 a 5 passos práticos numerados (parte mais salvável e compartilhável do vídeo)
- Pelo menos uma virada de perspectiva ("o que parecia certo é o que está te impedindo")
- Pelo menos uma evidência concreta: estudo citado, número, dado clínico ou caso real (anonimizado se necessário)
- Pelo menos uma analogia visual forte que o editor possa usar como B-roll

### A — Ação (últimos 60 a 90 segundos)

A função do bloco é dar o próximo passo concreto e fechar com retenção até o último segundo. Conteúdo:
- Sinal de alerta: quando o sintoma ou situação exige atenção médica/profissional. Esse bloco aumenta credibilidade e tempo de exibição
- CTA primário: agendar consulta, baixar material, seguir o canal, deixar comentário com algo específico
- CTA secundário: link da próxima recomendação (vídeo do canal que dá continuidade ao tema). Isso aumenta sessões e watch time, o sinal mais valioso para o algoritmo do YouTube
- Frase final que fecha o open loop aberto no início

Nunca encerrar com "valeu pessoal, até a próxima". Encerrar com gancho para o próximo vídeo.

### Técnicas de retenção que precisam aparecer ao longo do vídeo

Distribuídas no roteiro, não em um bloco só:

- **Pattern interrupt** a cada 30 a 60 segundos: mudança de ritmo, tom, nova pergunta, mudança de cenário ou close-up
- **Open loops múltiplos**: anunciar pelo menos dois itens específicos que serão revelados ao longo do vídeo
- **Re-hook na metade**: por volta da metade do vídeo, lembrar o espectador do valor que ainda vem ("e ainda falta o ponto mais importante, que é...")
- **Contradição produtiva**: pelo menos uma frase que quebra o senso comum e gera engajamento ("você ouviu a vida toda que X, e isso está errado")
- **Especificidade**: números concretos, exemplos com nome de exame, doses, idades. Quanto mais específico, mais retém
- **Frases curtas**: roteiro é texto falado, não escrito. Pontos finais. Pausas naturais

---

## Etapa 4: Escrita do roteiro

### Formato do texto

O roteiro deve ser escrito em tom falado, exatamente como o cliente vai dizer na frente da câmera. Não escrever em tom de artigo, tom de manual, tom de relatório. Tom de conversa, com a clareza de quem está olhando nos olhos da pessoa que assiste.

### Marcações obrigatórias no roteiro

Cada bloco AIDA precisa estar marcado com timestamp e função. Exemplo de marcação:

```
[0:00 — 0:30 | A — Atenção (Hook)]
[0:30 — 1:30 | I — Interesse (Por que isso acontece)]
[1:30 — 2:30 | D — Desejo (O erro mais comum) | base do CORTE 1]
[2:30 — 4:00 | D — Desejo (Os 5 passos práticos) | base do CORTE 2]
[4:00 — 5:00 | A — Ação (Sinal de alerta + CTA) | base do CORTE 3]
```

Cada bloco que tem potencial de virar corte para Reels/Shorts deve estar explicitamente marcado como "base do CORTE X".

### Tamanho-alvo

- Vídeo de 5 minutos: aproximadamente 750 a 900 palavras de roteiro falado
- Vídeo de 7 minutos: aproximadamente 1.000 a 1.250 palavras
- Vídeo de 10 minutos: aproximadamente 1.450 a 1.700 palavras

Cliente fala em média 150 palavras por minuto. Ajustar o roteiro para a duração-alvo escolhida.

---

## Etapa 5: Descrição otimizada para SEO do YouTube

A descrição não é só um campo informativo. É um dos elementos mais determinantes do alcance orgânico. Estruturar nesta ordem:

### 5.1 — Primeiras 150 caracteres (visíveis no resultado de busca)

São o que aparece no resultado da pesquisa do YouTube e do Google antes de o usuário clicar. Precisam conter:
- A palavra-chave principal exata, idealmente nas primeiras 25 palavras
- Promessa direta do que o vídeo entrega
- Razão para clicar

### 5.2 — Parágrafo descritivo (150 a 300 palavras)

Resumo do conteúdo do vídeo escrito de forma natural, com pelo menos:
- A palavra-chave principal repetida 2 a 3 vezes (sem keyword stuffing)
- Pelo menos 3 palavras-chave secundárias identificadas na pesquisa
- Menção explícita do nome do profissional (cria associação de busca pessoal)
- Resposta às perguntas mais buscadas no YouTube relacionadas ao tema

### 5.3 — Capítulos (timestamps)

Bloco obrigatório. O YouTube só reconhece capítulos se o primeiro timestamp for 00:00 e se houver pelo menos 3 timestamps no total. Formato:

```
00:00 Introdução
00:30 Por que [tema] acontece
01:30 O erro mais comum
02:30 Os 5 passos práticos
04:00 Sinal de alerta
```

Capítulos aumentam tempo de permanência e ajudam o algoritmo a entender o conteúdo. São obrigatórios em todos os vídeos longos.

### 5.4 — Links e CTAs na descrição

Bloco fixo que se repete em todos os vídeos do canal. Conteúdo:
- Link para agendamento ou WhatsApp do consultório
- Link para o Instagram (e outras redes)
- Link para playlist relacionada (vídeo seguinte recomendado)
- Disclaimer médico/profissional quando aplicável (em conteúdo de saúde, é obrigatório por boa prática e pelas regras do CFM)

### 5.5 — Hashtags

3 a 5 hashtags ao final da descrição. As três primeiras aparecem acima do título do vídeo. Combinar:
- 1 hashtag de alto volume (palavra-chave principal)
- 1 hashtag de nicho (ex: #nutrologia, #saudedamulher)
- 1 hashtag de marca pessoal (ex: #DrJoseRibeiro)

### 5.6 — Tags ocultas (no campo de tags do YouTube)

Não vão na descrição visível, mas a skill deve sempre sugerir 10 a 15 tags para o campo dedicado. Combinar:
- Variações da palavra-chave principal
- Sinônimos e termos populares
- Nome do profissional + "nutrólogo Recife" / cidade do consultório
- Termos de auto-complete identificados na pesquisa

---

## Etapa 6: Cortes para Reels/Shorts/TikTok

Para cada roteiro, sugerir 3 cortes de 60 a 90 segundos baseados em blocos do vídeo longo. Para cada corte, entregar:

- Tempo de origem no vídeo longo (ex: "do bloco 2:30 a 3:45")
- Duração final do corte
- Sugestão de título para o Reels (formato curto, com gancho)
- Indicação do que precisa ser ajustado na edição (legenda burned-in, CTA visual, formato 9:16)

---

## Etapa 7: Sugestão de thumbnail

A thumbnail é o segundo elemento mais determinante do CTR, junto com o título. Sugerir:

- Expressão facial específica do cliente (curioso, surpreso, alerta, sério)
- Elemento visual de fundo ou objeto em destaque (balança, ampola, exame, calendário, parte do corpo)
- 3 a 5 palavras grandes que aparecem na thumb, em alta contrastes de cor (vermelho, amarelo, branco sobre azul escuro)
- Indicação clara do que NÃO incluir (clichês visuais que reduzem credibilidade médica: setas exageradas, círculos vermelhos, expressão de pavor)

---

## Regras inegociáveis de estilo

### Linguagem

Roteiro de YouTube é texto falado. Tem que soar como conversa de melhores amigos: alguém olhando na câmera e contando para a melhor amiga ou para o melhor amigo do outro lado da tela. Natural, humana, direta. Ritmo fluido e narrativo, com encadeamento que não deixa quem está assistindo querer pular um pedaço.

A linguagem é sempre clara e didática, sem jamais perder a seriedade e a credibilidade do tema. Quando o assunto é saúde, ciência ou autoridade técnica, a leveza do tom não tira o peso da informação. Quem assiste percebe que está sendo cuidado por alguém que entende, mas que escolhe falar fácil.

**Critério inegociável de clareza**: o roteiro precisa ser compreendido por uma criança de 7 anos e por uma senhora de 70 ao mesmo tempo. Isso quer dizer:

- Termos técnicos só entram acompanhados de tradução imediata em palavras simples ou de uma analogia do dia a dia. Exemplo: "insulina, que é o porteiro do prédio onde mora a sua gordura".
- Frases curtas. Quando a frase começar a ficar longa, dividir.
- Uma ideia por frase. Sem subordinadas que se enrolam.
- Verbos no presente, voz ativa, sujeito explícito sempre que possível.
- Zero jargão sem tradução. Se uma palavra precisa ser explicada, ela vem com a explicação na mesma frase.
- Substituir construções abstratas por imagens concretas. Em vez de "fatores hormonais que influenciam o metabolismo basal", dizer "alguns hormônios que mandam no quanto de energia o seu corpo gasta".

A pessoa de 7 anos consegue acompanhar a história. A pessoa de 70 sente respeito pela informação. Os dois saem com a mesma compreensão do tema, em níveis diferentes de profundidade. Esse é o sinal de que o roteiro está pronto.

### O que nunca usar

- Travessões (nem como pontuação, nem como estilo)
- Emojis no roteiro falado (no texto da descrição é aceitável usar com parcimônia)
- "a gente" — sempre conjugação correta: "nós fazemos", "você faz", "eles fazem"
- Construções de IA: "não é sobre X... É sobre Y", "no cenário atual", "é fundamental", "neste contexto", "mergulhar em", "potencializar", "alavancar", "ressignificar", "jornada", "transformação"
- Frases isoladas como gancho dramático falso: "Resultado?", "A verdade que ninguém te fala?", "Sabe o que aconteceu?"
- Etiquetas explícitas de narrativa: "O problema é X", "O pior:", "A verdade incômoda é:", "O segredo é:". Mostrar, não anunciar
- Tricolon de repetição: três frases paralelas dizendo a mesma coisa em variações
- Vinheta longa de abertura, agradecimento de início, pedido de like e inscrição no início do vídeo (todos derrubam retenção)
- Conselhos genéricos sem especificidade clínica/técnica
- Comparação com colegas ou concorrentes específicos
- Promessa milagrosa, cura, garantia de resultado em conteúdo de saúde

### O que sempre garantir

- Clareza absoluta: cada frase precisa ser entendida na primeira vez que é ouvida
- Voz ativa: o espectador é o agente ("você decide", "você faz"), nunca o paciente passivo
- Especificidade: números, nomes de exames, doses, idades, casos concretos
- Frases curtas, pontos finais, pausas naturais
- Português correto: acentuação, pontuação, concordância, regência
- Tom de autoridade sem arrogância, acolhimento sem condescendência
- Cumprimento ético quando o tema é saúde: indicar que o conteúdo é educativo, não substitui consulta, e citar quando o caso exige investigação profissional

### Tom de voz

Adapta-se ao briefing do cliente. Médico técnico-didático, médico storyteller, especialista provocador, comunicador acolhedor — a skill se ajusta ao perfil identificado no documento de estratégia.

---

## Etapa 8: Revisão antes de entregar

Antes de apresentar o roteiro completo, fazer varredura interna:

- O hook tem no máximo 30 segundos? Está direto, sem vinheta longa?
- O título do vídeo segue os padrões do benchmark identificado?
- Existe pelo menos um open loop anunciado no Hook e fechado no final?
- Existe pattern interrupt distribuído ao longo do vídeo (não concentrado em um bloco só)?
- Existe pelo menos um número, dado ou referência concreta no bloco D?
- O CTA está escrito de forma completa, com verbo e convite claro?
- Os timestamps estão marcados em cada bloco AIDA?
- Os 3 cortes para Reels estão indicados no roteiro com tempo de origem?
- A descrição tem capítulos com primeiro timestamp em 00:00?
- A descrição tem palavra-chave principal nos primeiros 25 caracteres?
- Há "a gente" em algum lugar? Substituir por conjugação correta. Sem exceção.
- Há etiquetas explícitas de narrativa? Reescrever direto.
- Há tricolon de repetição? Reduzir para a formulação mais precisa.
- O leitor está em voz ativa? Reescrever o que estiver passivo.
- Roteiro tem o número de palavras compatível com a duração-alvo (150 palavras por minuto)?
- O tema exige disclaimer de saúde? Incluir na descrição.
- O roteiro passaria no teste dos 7 aos 70? Cada termo técnico tem tradução imediata? Cada conceito abstrato tem imagem concreta? Se alguma frase exige releitura para ser entendida, reescrever.
- O ritmo está fluido e narrativo? Cada bloco emenda no próximo sem solavanco? Se algum trecho parece "quebrado", suavizar a transição.

---

## Formato de entrega

Apresentar a entrega completa nesta estrutura, nesta ordem. Não adicionar comentários sobre as escolhas feitas. Não explicar o método. Entregar o material pronto para uso.

```
═══════════════════════════════════════════
BLOCO 1 — BENCHMARK E PESQUISA
═══════════════════════════════════════════

TÍTULOS DE REFERÊNCIA NO NICHO
[Lista de 6 a 10 títulos de alta performance encontrados na pesquisa, com faixa de visualizações e padrão estrutural]

TERMOS MAIS BUSCADOS NO YOUTUBE SOBRE O TEMA
[Lista de 10 a 15 termos relacionados, ordenados por probabilidade de busca]

CANAIS E VÍDEOS EM ASCENSÃO NO NICHO (vidIQ, quando disponível)
[Canais de referência ativos, vídeos ganhando tração agora, termos usados por quem está crescendo rápido — ou aviso de que essa camada não pôde ser checada]

═══════════════════════════════════════════
BLOCO 2 — TÍTULO E THUMBNAIL
═══════════════════════════════════════════

TÍTULO DO VÍDEO (até 60 caracteres)
[Título escolhido]

SUGESTÃO DE THUMBNAIL
[Descrição visual: expressão, elemento de fundo, palavras grandes em destaque, paleta]

═══════════════════════════════════════════
BLOCO 3 — ROTEIRO COMPLETO (AIDA)
═══════════════════════════════════════════

[0:00 — 0:30 | A — Atenção (Hook)]
[Texto falado]

[0:30 — 1:30 | I — Interesse]
[Texto falado]

[1:30 — 2:30 | D — Desejo (Erro comum) | base do CORTE 1]
[Texto falado]

[2:30 — 4:00 | D — Desejo (Passos práticos) | base do CORTE 2]
[Texto falado]

[4:00 — 5:00 | A — Ação (Alerta + CTA) | base do CORTE 3]
[Texto falado]

═══════════════════════════════════════════
BLOCO 4 — DESCRIÇÃO OTIMIZADA PARA YOUTUBE
═══════════════════════════════════════════

[Primeiras 150 caracteres com palavra-chave principal]

[Parágrafo descritivo de 150 a 300 palavras]

CAPÍTULOS:
00:00 [Nome]
00:30 [Nome]
01:30 [Nome]
[...]

LINKS:
[Bloco de links — agendamento, Instagram, playlist]

[Disclaimer de saúde se aplicável]

#hashtag1 #hashtag2 #hashtag3 #hashtag4 #hashtag5

═══════════════════════════════════════════
BLOCO 5 — TAGS PARA O CAMPO DE TAGS
═══════════════════════════════════════════

[Lista de 10 a 15 tags separadas por vírgula]

═══════════════════════════════════════════
BLOCO 6 — CORTES PARA REELS/SHORTS
═══════════════════════════════════════════

CORTE 1 (60 a 90s)
Origem: [tempo do vídeo longo]
Título do Reels: [título curto com gancho]
Ajustes de edição: [legenda burned-in, formato 9:16, CTA visual]

CORTE 2 (60 a 90s)
[mesma estrutura]

CORTE 3 (60 a 90s)
[mesma estrutura]
```

Se o usuário pedir ajuste, incorporar o feedback e reescrever o que for necessário sem perguntar se pode. Apenas fazer.

Se o usuário pedir vários roteiros de uma vez (ex: "me entrega 4 roteiros para o canal"), aplicar o método para cada tema individualmente, mantendo a coerência com o documento de estratégia. Pesquisa de benchmark pode ser feita uma vez para o conjunto se os temas forem do mesmo nicho amplo.