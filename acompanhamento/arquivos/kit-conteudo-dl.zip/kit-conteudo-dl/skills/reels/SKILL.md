---
name: reels
description: >
  Cria roteiros de vídeos virais curtos (até 2 minutos) para Instagram Reels, TikTok e YouTube Shorts pelo Método Dani.
  Use sempre que o usuário pedir roteiro de Reels, TikTok, Shorts, vídeo curto, vídeo viral, conteúdo para o feed, ou variações como "me faz um Reels", "ideia de viral", "vídeo pra postar hoje", "conteúdo curto", "Shorts", "TikTok".
  Antes de perguntar qualquer coisa, lê arquivos de estratégia do projeto (estrategia.md, briefing.md, Estrategia*.docx) e o contexto da pasta do cliente — só pergunta o que faltar.
  Pesquisa via WebSearch os temas mais viralizados nos últimos dias no nicho, identifica formatos em alta no Instagram e TikTok, e gera o roteiro completo: hook de 3 segundos que paralisa o scroll, desenvolvimento AIDA, lacuna em aberto que obriga o espectador a seguir o perfil, CTA de crescimento (seguir, compartilhar) e hacks de edição com base no algoritmo para maximizar retenção e alcance.
---

# Método Dani — Vídeos Virais Curtos

## Princípio central

Vídeo curto vive ou morre nos primeiros 3 segundos. Se o scroll não para, nada que vem depois importa. O algoritmo do Instagram, do TikTok e do YouTube Shorts mede tudo a partir disso: completion rate, replays, salvamentos, compartilhamentos. Quanto mais um vídeo retém, mais ele é entregue. O Método Dani aplica três princípios em sequência: hook que paralisa, desenvolvimento AIDA que mantém atenção até o último segundo, e lacuna mental no final que faz o espectador querer voltar — não fechar e ir pro próximo.

Cada roteiro precisa ser pensado como um pacote: hook, conteúdo, gancho de retorno, CTA de crescimento, hacks de edição. Sem um desses pilares, o vídeo perde força.

---

## Etapa 1: Leitura de contexto do projeto

Antes de perguntar qualquer coisa, faça uma varredura silenciosa para entender o contexto. Siga esta ordem:

**Passo 1 — Procurar documento de estratégia**
Localizar arquivos como `estrategia.md`, `Estrategia*.docx`, `briefing.md`, `cliente.md`, `perfil.md` ou qualquer arquivo `.md`, `.txt`, `.docx` que pareça documento de estratégia. Use Glob ou Read.

**Passo 2 — Se não houver arquivo de estratégia**
Leia os demais arquivos da pasta do projeto que possam conter informações sobre cliente, público-alvo, pilares, tom ou objetivo.

**Passo 3 — Se não houver pasta de projeto montada**
Leia o histórico da conversa atual.

**Passo 4 — Montar o briefing interno (sem exibir ao usuário)**
Reúna: especialidade ou nicho do cliente, público-alvo, pilares de conteúdo, tom de voz, objetivo estratégico, restrições.

**Passo 5 — Perguntar apenas o que falta**
Se o briefing estiver completo, a única pergunta é o tema do vídeo (ou se o usuário quer que a skill sugira ideias virais a partir do nicho). Nunca repita perguntas cujas respostas já estão no contexto.

---

## Etapa 2: Pesquisa de temas virais e análise de nicho

Esta etapa é obrigatória antes de gerar qualquer roteiro. Sem ela, o conteúdo nasce desconectado do que está performando agora.

### 2.1 — Identificar o nicho e o público

A partir do briefing, defina internamente:
- Nicho amplo (saúde, finanças, beleza, fitness, etc.)
- Subnicho específico (nutrologia, menopausa, hipertrofia, etc.)
- Persona principal (faixa etária, dor central, comportamento digital)
- Plataforma prioritária (Instagram, TikTok, Shorts) — costuma ser Instagram para Brasil em saúde e bem-estar, TikTok para Geração Z, Shorts para topo de funil

### 2.2 — Pesquisa de temas em alta nos últimos dias

Use WebSearch para identificar o que está viralizando no nicho. Combinar queries como:

- "[nicho] viral instagram últimos dias"
- "[nicho] reels milhões de visualizações"
- "[subnicho] tiktok viral"
- "trending topics [nicho] 2026"
- "vídeo viral [tema] instagram"

Recolha pelo menos 5 a 8 sinais do que está funcionando agora:
- Tipos de vídeo que estão repetindo no nicho (reaction, transformação, mito vs verdade, resposta a comentário, lista rápida, antes/depois, encenação)
- Áudios em alta (se possível identificar)
- Frases de hook que estão sendo usadas
- Formato visual dominante (close-up de rosto, gravação caseira, encenação, animação simples)

### 2.3 — Geração de 5 a 10 ideias virais para o nicho

Com base na pesquisa, gere ideias de vídeos virais combinando:
- Os temas mais viralizados do momento
- Os pilares de conteúdo do cliente
- Os formatos que estão funcionando agora

Cada ideia deve vir com: tema, formato (encenação, reaction, lista, mito vs verdade, etc.), gancho central e razão pela qual tende a viralizar.

Se o usuário pediu um vídeo específico, pular essa etapa e ir direto ao roteiro. Se pediu "ideias", entregar a lista antes.

---

## Etapa 3: Hook de 3 segundos — a regra que decide tudo

Os primeiros 3 segundos não podem informar. Precisam interromper. O hook é a parte mais reescrita do roteiro. Se ele funciona, o resto importa. Se não funciona, nem o melhor conteúdo do mundo salva.

### Padrões de hook que paralisam o scroll

- **Afirmação que quebra crença**: "Você ouviu a vida toda que ovo aumenta colesterol. É mentira."
- **Pergunta com paradoxo**: "Por que você dorme oito horas e acorda mais cansada?"
- **Confissão impactante em primeira pessoa**: "Eu emagreci 12 quilos sem entrar em academia. Vou te contar como."
- **Número específico que gera curiosidade**: "Existem 3 sintomas de tireoide que ninguém te conta no consultório."
- **Cenário visual contraintuitivo**: começar mostrando algo que parece errado (ex: o médico no chão, no chuveiro, com a balança quebrada) e ancorar com uma frase que explica.
- **Pare tudo**: "Pare tudo se você já tomou anticoncepcional por mais de 5 anos."
- **Acusação direta**: "Você está fazendo errado. E nem sabe."
- **Revelação de rotina/segredo**: "O que eu como antes de dormir pra acordar com energia."
- **Pergunta que a persona faz pra ela mesma**: "Por que você não emagrece nem comendo pouco?"

### O que nunca colocar no hook

- "Oi gente, tudo bem com vocês?"
- "Hoje eu vim falar sobre..."
- "Nesse vídeo a gente vai..."
- Qualquer apresentação antes do hook
- Qualquer agradecimento
- Qualquer "antes de começar deixa o like"

### Reforço visual no hook

O hook precisa ter:
- Texto na tela nas primeiras 2 frames (palavra-chave grande, contrastante)
- Movimento ou corte rápido nos primeiros 1.5s para impedir scroll automático
- Expressão facial forte se for plano com pessoa (intensidade no olhar, urgência, surpresa)

---

## Etapa 4: Estrutura AIDA aplicada ao vídeo curto

Vídeo curto comprime AIDA em até 2 minutos. A divisão típica:

### A — Atenção (0:00 a 0:03)
Hook conforme regras da Etapa 3. Direto, sem rodeio.

### I — Interesse (0:03 a 0:15 ou 0:03 a 0:25 dependendo da duração total)
Validação rápida do problema ou contexto da promessa do hook. Por que isso importa pra quem está assistindo. Aqui se ancora a atenção e se anuncia o que vem (open loop curto: "vou te explicar em 60 segundos").

### D — Desejo (do final do bloco I até 80% do vídeo)
Coração do conteúdo. Entregar o valor com:
- 1 a 3 pontos máximos. Não mais
- Especificidade clínica ou prática (números, exemplos concretos)
- Pelo menos uma virada de perspectiva ou contraste forte
- Ritmo de cortes curto, mudança de plano, texto na tela reforçando o que está sendo dito

### A — Ação (últimos 5 a 10 segundos)
Duas camadas obrigatórias:
1. **Lacuna em aberto** (a peça mais importante): uma frase que abre um loop mental e faz a pessoa querer voltar ao perfil. Exemplos abaixo.
2. **CTA de crescimento**: seguir, compartilhar, salvar. Específico, contextual, nunca genérico.

### Tamanho-alvo

- Vídeo de 30 a 45 segundos: aproximadamente 90 a 130 palavras de roteiro
- Vídeo de 60 a 90 segundos: aproximadamente 180 a 270 palavras
- Vídeo de até 2 minutos: aproximadamente 350 a 450 palavras

A pessoa fala em ritmo natural cerca de 150 palavras por minuto. Vídeo curto é editado em ritmo mais rápido (cortes encurtam pausas), então o roteiro pode caber um pouco mais palavras do que o tempo bruto sugere.

---

## Etapa 5: Lacuna em aberto — a técnica que faz seguir o perfil

A grande diferença entre um vídeo viral que ganha alcance e um vídeo viral que ganha seguidor é a lacuna em aberto. O algoritmo entrega o vídeo. A lacuna entrega o seguidor.

### Como construir a lacuna em aberto

A lacuna em aberto é uma frase, no final do vídeo, que cumpre três requisitos:
1. Faz referência a algo específico que NÃO foi entregue no vídeo
2. Sugere que esse "algo" está em outro vídeo ou virá em breve
3. Cria desconforto cognitivo: o cérebro do espectador entra em loop pedindo a informação que faltou

### Padrões de lacuna em aberto

- **Continuação anunciada**: "No próximo vídeo eu mostro o protocolo completo. Me segue pra não perder."
- **Provocação seletiva**: "Se você marcou três ou mais sintomas, tem outro vídeo no meu perfil que muda tudo. Me segue."
- **Pergunta sem resposta entregue**: "E você? Já testou esses 3 exames? Me conta nos comentários — e me segue, porque a resposta que mais importa eu vou dar no próximo."
- **Promessa de revelação**: "Tem uma coisa que eu nunca contei aqui sobre [tema]. Me segue, porque vou contar essa semana."
- **Caso real com final em aberto**: contar uma história curta e parar antes do desfecho — "o que aconteceu com ela? Conto no próximo. Me segue pra ver."

### Como nunca construir a lacuna

- Sem ser específico (lacuna genérica não vicia: "tem mais conteúdo no perfil" não funciona)
- Sem o CTA grudado: a frase tem que terminar com o convite para seguir, salvar ou compartilhar
- Sem clichê: "deixa o like" não é lacuna em aberto, é interrupção

---

## Etapa 6: CTA de crescimento

O CTA não é um item solto. Ele está colado na lacuna em aberto. As ações priorizadas, em ordem de impacto algorítmico no Instagram:

1. **Compartilhar** (peso máximo no algoritmo)
2. **Salvar** (segundo maior peso)
3. **Comentar** (gera resposta e estende sessão)
4. **Seguir** (objetivo final do vídeo viral em topo de funil)

Pelo menos uma dessas ações precisa estar pedida explicitamente. Se o objetivo é alcance puro, pedir compartilhamento. Se é crescimento de perfil, pedir seguir + compartilhar. Se é autoridade construída ao longo do tempo, pedir salvar.

---

## Etapa 7: Hacks de edição baseados no algoritmo

Ao final de cada roteiro, sugerir hacks específicos de edição que aumentam a retenção e o alcance. Não são opcionais — fazem parte da entrega.

### Hacks que sempre devem aparecer

- **Legenda burned-in**: 90% das pessoas assistem sem som. Texto queimado na imagem dobra a retenção
- **Cortes a cada 1 a 2 segundos**: jump cut, mudança de plano, B-roll. Olho que para de ver mudança fecha o vídeo
- **Texto na tela reforçando palavras-chave**: a cada virada do roteiro, palavra ou frase chave aparece grande na tela
- **Loop seamless**: o último frame deve emendar visualmente no primeiro. O algoritmo conta replay como retenção, e se a transição é invisível, o espectador assiste 2 ou 3 vezes sem perceber
- **Pausa de 0.5s antes da virada**: criar expectativa antes de revelar a informação principal. O cérebro fica preso esperando a resposta
- **Capa (cover) com texto grande**: a primeira coisa que aparece quando o vídeo é compartilhado. Texto curto, contrastante, anunciando o gancho do vídeo

### Hacks que dependem do tipo de vídeo

- **Reaction com texto sobreposto**: se o roteiro responde a algo (notícia, vídeo de outra pessoa, comentário), inserir o estímulo original como B-roll com texto explicativo
- **Antes e depois lado a lado**: para temas de transformação, mostrar os dois cenários no mesmo frame
- **Zoom in abrupto na revelação**: quando o ponto mais importante é dito, zoom rápido no rosto ou no objeto. Pattern interrupt visual
- **Sound effect em transições**: whoosh, click, pop. Acordam a atenção
- **Mudança de cenário no meio**: gravar um trecho na cozinha, outro no consultório, outro no carro. Variação visual segura retenção

### Áudio e hashtags (também impactam algoritmo)

- Sempre que possível, usar áudio em alta na plataforma (Instagram mostra na lupa do feed o que está em ascensão)
- 3 a 5 hashtags na legenda — não 30. Misturar volume alto + nicho
- Legenda com primeira frase forte (até 125 caracteres aparecem antes do "ver mais"), com a palavra-chave nas primeiras 25 palavras

---

## Etapa 8: Domínio do algoritmo do Instagram (resumo prático)

A skill aplica esses princípios em todo roteiro:

- **Watch time / completion rate** é o sinal mais forte. Todo o roteiro existe pra fazer a pessoa assistir até o fim
- **Replays valem como retenção**. Loop seamless, surpresa no final, gancho que faz reassistir são técnicas certeiras
- **Compartilhamento e salvamento têm o maior peso direto**. Conteúdo "salva-vida", listas práticas, mitos quebrados são os formatos que mais geram esses dois sinais
- **Comentário estende sessão**. Provocar comentário (pergunta no final, opinião polêmica em dose certa) ajuda
- **Tempo no perfil aumenta exponencialmente quando o espectador clica no perfil**. A lacuna em aberto serve exatamente pra isso
- **Áudio em alta + hashtag de nicho + capa atraente = entrada na lupa do Instagram**, que é onde mora o crescimento orgânico
- **Postagem em horário ativo da persona** (default Brasil em saúde e bem-estar: 12h, 19h e 21h) — sugerir no fim da entrega quando relevante

---

## Regras inegociáveis de estilo

### Linguagem

Vídeo curto é texto falado. Tem que soar como conversa de melhores amigos: alguém olhando na câmera e falando com a melhor amiga ou o melhor amigo. Natural, humana, direta. Ritmo fluido e narrativo.

A linguagem é sempre clara e didática, sem perder seriedade nem credibilidade. O critério é o mesmo da skill de YouTube: o roteiro precisa ser compreendido por uma criança de 7 anos e por uma senhora de 70 ao mesmo tempo.

- Termos técnicos só entram com tradução imediata ou analogia do dia a dia
- Frases curtas, uma ideia por frase
- Verbos no presente, voz ativa, sujeito explícito
- Zero jargão sem tradução
- Construções abstratas viram imagens concretas

### O que nunca usar

- Travessões
- Emojis no roteiro falado
- "a gente" — sempre conjugação correta
- Construções de IA: "não é sobre X... É sobre Y", "no cenário atual", "é fundamental", "neste contexto", "mergulhar em", "potencializar", "alavancar", "ressignificar", "jornada", "transformação"
- Frases isoladas como gancho dramático falso: "Resultado?", "A verdade que ninguém te fala?", "Sabe o que aconteceu?"
- Etiquetas explícitas de narrativa: "O problema é X", "O pior:", "A verdade incômoda é:", "O segredo é:"
- Tricolon de repetição (três frases paralelas dizendo o mesmo)
- Vinheta longa de abertura, agradecimento de início, "antes de começar deixa o like"
- Comparação com colegas ou concorrentes específicos
- Promessa milagrosa, cura, garantia de resultado em conteúdo de saúde
- "Confere o link na bio" como CTA único — fraco. Sempre dar uma ação concreta antes (seguir, compartilhar)

### O que sempre garantir

- Hook em 3 segundos com texto na tela
- Voz ativa: o espectador é o agente
- Especificidade: números, idades, exames, doses, casos concretos
- Português correto: acentuação, pontuação, concordância
- Tom de autoridade sem arrogância, acolhimento sem condescendência
- Disclaimer de saúde quando relevante (legenda, não no áudio do vídeo curto)
- Lacuna em aberto + CTA de crescimento no final, sempre

---

## Etapa 9: Revisão antes de entregar

Antes de apresentar, fazer varredura interna:

- O hook tem no máximo 3 segundos? Quebra crença, traz paradoxo ou afirmação forte?
- Os primeiros 3 segundos têm texto na tela sugerido?
- O roteiro cabe no tempo-alvo (até 2 minutos)?
- Existe pelo menos uma virada de perspectiva ou contraste?
- A especificidade está presente (números, exemplos concretos)?
- A lacuna em aberto está construída de forma específica (não genérica)?
- O CTA de crescimento (seguir, compartilhar, salvar) está colado na lacuna?
- Os hacks de edição foram entregues, com pelo menos 4 itens específicos para o vídeo?
- O roteiro passa no teste dos 7 aos 70?
- Há "a gente"? Substituir por conjugação correta. Sem exceção
- Há etiquetas explícitas de narrativa? Reescrever direto
- Há tricolon de repetição? Reduzir para a formulação mais precisa
- O leitor está em voz ativa em todo o roteiro?

---

## Formato de entrega

Apresentar nesta estrutura, nesta ordem. Sem comentário sobre as escolhas, sem explicação do método. Material pronto para uso.

```
═══════════════════════════════════════════
BLOCO 1 — ANÁLISE DE NICHO E PESQUISA VIRAL
═══════════════════════════════════════════

NICHO E PÚBLICO IDENTIFICADOS
[Resumo curto: nicho, subnicho, persona, plataforma prioritária]

TEMAS EM ALTA NO NICHO (últimos dias)
[Lista de 5 a 8 sinais: temas, formatos, ganchos repetidos]

═══════════════════════════════════════════
BLOCO 2 — IDEIAS VIRAIS (se solicitadas)
═══════════════════════════════════════════

[Lista de 5 a 10 ideias, cada uma com: tema, formato, gancho central, razão para viralizar]

[Se o usuário pediu um vídeo específico, pular esse bloco]

═══════════════════════════════════════════
BLOCO 3 — ROTEIRO COMPLETO
═══════════════════════════════════════════

TÍTULO/CONCEITO DO VÍDEO
[Frase curta]

DURAÇÃO ALVO
[30s, 60s, 90s ou 2min]

[0:00 — 0:03 | A — HOOK]
[Texto falado]
TEXTO NA TELA: [palavra ou frase grande]

[0:03 — 0:15 | I — Interesse]
[Texto falado]

[0:15 — 0:50 | D — Desejo (conteúdo)]
[Texto falado]

[0:50 — 0:60 | A — Ação (lacuna + CTA)]
[Texto falado com a lacuna em aberto e o CTA de crescimento]

═══════════════════════════════════════════
BLOCO 4 — LEGENDA, HASHTAGS E CAPA
═══════════════════════════════════════════

LEGENDA (primeira frase forte com palavra-chave nos primeiros 125 caracteres)
[Texto da legenda completa]

HASHTAGS (3 a 5)
#hashtag1 #hashtag2 #hashtag3 #hashtag4 #hashtag5

CAPA (texto da thumbnail/cover)
[3 a 5 palavras grandes que aparecem na capa]

═══════════════════════════════════════════
BLOCO 5 — HACKS DE EDIÇÃO
═══════════════════════════════════════════

[Lista de 4 a 7 hacks específicos para esse roteiro: cortes, texto na tela, transições, loop, sound effects, capa, áudio em alta]

═══════════════════════════════════════════
BLOCO 6 — DICA DE PUBLICAÇÃO (quando relevante)
═══════════════════════════════════════════

[Horário sugerido, áudio em alta a checar na plataforma, observação de timing com tema viral]
```

Se o usuário pedir ajuste, incorporar e reescrever sem perguntar se pode. Apenas fazer.

Se o usuário pedir vários roteiros de uma vez (ex: "me entrega 5 ideias de Reels viralizáveis"), entregar primeiro o Bloco 1 (análise + temas em alta) uma vez, depois as ideias, e então — se solicitado — desenvolver os roteiros completos um a um.
