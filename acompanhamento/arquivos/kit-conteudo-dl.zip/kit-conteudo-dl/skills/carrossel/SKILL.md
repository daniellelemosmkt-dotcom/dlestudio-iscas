---
name: carrossel
description: "Skill especializada na criação de carrosséis estratégicos de alta conversão para Instagram usando o Método Dani. Use sempre que o usuário pedir um carrossel, conteúdo para Instagram, roteiro de slides, sequência de cards, ou qualquer variação de \"me ajuda a escrever um carrossel\". Também dispara quando o usuário menciona querer criar conteúdo que \"conduza percepção\", \"gere autoridade\", \"converta\" ou \"atraia seguidores\". Antes de perguntar qualquer coisa, a skill lê automaticamente o documento de estratégia do projeto (estrategia.md ou similar) ou os arquivos disponíveis na pasta do cliente, e só pergunta o que ainda estiver faltando, normalmente apenas o tema do carrossel. Escolhe o modelo mais adequado entre 10 frameworks e entrega um carrossel completo do Card 1 até no máximo Card 10, com linguagem humana, fluida e estratégica."
---

# Método Dani — Carrosséis de Alta Conversão

## Regra inegociável: SEMPRE invocar esta skill antes de escrever, nunca escrever de memória

Esta skill precisa ser efetivamente acionada (via ferramenta Skill, ou releitura completa deste arquivo) imediatamente antes de escrever qualquer carrossel novo — mesmo quando o arquivo já foi lido antes na mesma conversa, mesmo quando parece redundante, mesmo em uma sessão longa de produção em lote. Nunca escrever um carrossel "de memória", confiando em ter internalizado as regras de leituras anteriores. Essa é exatamente a falha que reintroduz vícios de IA proibidos (como a construção "não é sobre X... é sobre Y", que está na lista de proibições abaixo e já vazou para conteúdo entregue por confiar na memória em vez de reler o método). Isso vale para toda e qualquer peça de conteúdo, não só para o primeiro carrossel de uma sessão: se a sessão vai produzir três, cinco, dez carrosséis seguidos, a skill é reconferida a cada um.

## Princípio central

Todo carrossel conduz percepção, gera tensão e provoca uma mudança de consciência. É um conteúdo informativo, com leveza e bom humor, em que o leitor aprende sem perceber. É conteúdo estratégico. A diferença está em cada palavra escolhida, em cada virada narrativa e na sensação que o leitor carrega depois que fecha o último card.

## Etapa 1: Leitura de contexto do projeto

Antes de perguntar qualquer coisa, faça uma varredura silenciosa para entender se o contexto do cliente já está disponível. Siga esta ordem:

**Passo 1 — Procurar documento de estratégia**
Tente localizar um arquivo chamado `estrategia.md` na pasta do projeto montado. Se não encontrar com esse nome exato, tente variações como `estrategia-cliente.md`, `briefing.md`, `cliente.md`, `perfil.md` ou qualquer arquivo `.md` ou `.txt` que pareça ser um documento de estratégia ou briefing. Use a ferramenta Glob ou Read para isso.

**Passo 2 — Se não houver arquivo de estratégia**
Leia os demais arquivos disponíveis na pasta do projeto (documentos, textos, anotações) que possam conter informações sobre o cliente, público-alvo, tom ou objetivo. Use Glob para listar o conteúdo da pasta e Read para ler os arquivos relevantes.

**Passo 3 — Se não houver pasta de projeto montada**
Leia o histórico da conversa atual para identificar informações sobre o cliente, público-alvo, tom de voz e objetivo que já tenham sido mencionados.

**Passo 4 — Montar o briefing interno**
Com base no que foi encontrado, monte internamente (sem exibir ao usuário) um briefing com o que já sabe sobre:
- Público-alvo
- Tom de voz
- Objetivo estratégico padrão
- Restrições ou contexto específico do cliente

**Passo 5 — Perguntar apenas o que falta**
Só pergunte ao usuário o que não foi possível identificar. Se o documento de estratégia estiver completo, a única pergunta necessária é o tema do carrossel. Se faltar algum campo, pergunte apenas aquele campo. Nunca repita perguntas cujas respostas já estão no contexto.

Os cinco campos que precisam estar preenchidos antes de escrever:
1. **Tema** — Sobre o que é o carrossel?
2. **Objetivo estratégico** — O que este conteúdo precisa fazer?
3. **Público-alvo** — Quem é essa pessoa? O que ela sente, teme, deseja?
4. **Tom de voz** — Como deve soar?
5. **Referência ou contexto específico** — Algum dado, história ou ângulo específico?

---

## Etapa 2: Seleção de modelo (processo interno — não exibir na resposta)

Com base nas respostas coletadas, escolha mentalmente o modelo mais adequado entre os modelos abaixo. Justifique internamente sua escolha com base no objetivo do conteúdo. Mencione o modelo escolhido na resposta final.

### Modelos disponiveis

**1. Quebra de objeção comum / ruptura de consciência**
Ideal quando a persona tem uma crença limitante que a impede de agir. O carrossel desfaz essa crença card a card, de forma leve, tirando a culpa do leitor e mostrando uma solução, com narrativa fluida e provocação emocional.

**2. Direcionamento estratégico**
Usado no meio do funil de conteudos para elevar a consciencia da persona. O conteúdo funciona como um mapa: mostra onde ela está (o problema, dor, vida dos sonhos), onde pode chegar e como o produto ou serviço é a solução. Deve ser didático, fluido e parecer uma conversa como se conhecesse profundamente a persona.


**3. Tradução técnica**
Ideal quando o conteúdo é complexo e precisa ser simplificado sem perder a credibilidade. O objetivo é fazer a persona sentir que finalmente entendeu algo que parecia complicado — e que essa compreensão só veio por causa de quem escreveu. Sempre didático, usando storytelling, analogias ou ganchos com figuras conhecidas para tornar simples. O teste de perfomance é garantir que esse conteúdo seja compreendido desde uma criança de 7 anos até uma senhora de 70 anos.



**4. Storytelling — Ponte da Epifania (Russell Brunson)**
Conteúdo em formato de historia que pode ser a da propria pessoa, de cliente ou usar uma figura publica para gancho. Estrutura: momento anterior ao insight (dificuldade, problema, desejo, obstaculos), contextualize como um livro de literatura com detalhes que abram a imaginação de quem le e a faz se visualizar dentro da história, o que provocou a virada, o que mudou depois, como isso se aplica à vida do leitor. e como a partir de agora o produto ou serviço pode levar o leitor a viver a mesma virada. O objetivo é criar identificação profunda, substituir as crenças internas e externas e gerar desejo profundo pelo serviço.

**5. Contraste de cenário**
Ideal quando dá para pintar dois mundos lado a lado: um que representa o problema atual da persona (o que ela vive e não quer mais) e outro que representa o desejo real (o que ela quer mas ainda não tem). Cada card de contraste deve ser dividido visualmente ao meio, com os dois cenários coexistindo no mesmo card. Os cenários precisam ser ultra-concretos e sensoriais, não abstratos. Exemplos do nível de especificidade esperado: "ela atende convênios porque precisa lotar a agenda para cobrir os custos do consultório" x "ela escolheu atender apenas particular, tem tempo para cada paciente e vai para casa às 17h". Nunca use o contraste para diminuir quem está no cenário ruim nem para criar atrito com colegas de profissão. O contraste é entre dois estados de vida, não entre pessoas certas e erradas. Ao final a condução deve ser para identificação, compartilhamento ou ação de compra.

**6. Quebra de Mitos**
Ideal quando a persona carrega crenças incorretas que a impedem de buscar cuidado ou tomar decisões certas. O médico ou especialista aparece como autoridade prática que desfaz mitos comuns com clareza e sem arrogância. Antes de escrever, solicite ao usuário: especialidade, tema central, tom desejado, tempo de formação ou experiência e o arroba do perfil para o CTA.

Estrutura fixa deste modelo:
- Card 1 (Autoridade): gancho que paralisa o scrool e desperta um instindo primário como medo, curiosidade, desejo
- Cards 2 a 8 (Mitos): um mito por card. Cada card traz uma crença comum, explica em uma frase simples a razão real e oferece uma orientação prática
- Card 9 (CTA): convite direto e humano para seguir o perfil (@perfil)

Regras específicas deste modelo: educativo, linguagem simples, didático, autoridade sem arrogância, frases curtas em cada card como se fossem uma conversa do médico com o paciente.

**7. Educativo de utilidade publica**
Ideal quando o objetivo é acolher a persona que sofre com sintomas pouco falados, reduzir culpa e mostrar que existe solução com acompanhamento. Antes de escrever, solicite ao usuário: persona, fase ou condição, tom desejado e número de sintomas a abordar.

Estrutura fixa deste modelo:
- Card 1 - Gancho que paralise o scrool (ex: Te disseram que dor nas costas é normal, mas esses 5 fatos vão te provar o contrário.)
- Card 2 (Contexto): conexão direta com o leitor e causa geral do quadro (ex.: hormonal, imunológica, emocional)
- Cards 3 a 5 : descrição curta do que a pessoa sente e explicação fisiológica simples, sem jargão técnico, oferecendo solução ao final de cada card
- Card 6 (Reframe): mostra a solução de forma prática, substitui as crenças internas e prepara a persona para ação
- Card 7 (CTA): deve gerar uma ação imediata


Regras específicas deste modelo: educativo, acolhedor, sem alarmismo, linguagem simples, autoridade médica implícita no texto, nunca explicitada com arrogância.

---

## Etapa 3: Escrita do carrossel

### Limite de cards: no máximo 10, sem excesso de fragmentação

Nenhum carrossel deste método ultrapassa 10 cards, capa e CTA final inclusos. Máximo não é meta: um carrossel de 7 ou 8 cards bem construído é melhor que um de 10 cards artificialmente esticado. Um card só é dividido em dois quando há um motivo real: densidade de texto que não cabe em uma peça de design (mais de aproximadamente 300 a 350 caracteres tende a pesar demais num card só), o card mistura dois subtemas genuinamente distintos que merecem cada um seu próprio card (por exemplo, sexualidade e sono são dois assuntos diferentes, mesmo que relacionados), ou o card acumula funções demais (por exemplo, definição + CTA de compartilhamento + pergunta de transição pro próximo card no mesmo bloco) e funciona como uma "segunda capa" densa em vez de um card só. Nunca divida um card só porque ele é longo se o conteúdo é uma única ideia contínua, isso gera fragmentação artificial, cards fracos que não sustentam sozinhos, e estoura o limite de 10 à toa. Ao revisar um carrossel já escrito para redistribuir em mais cards, sempre volte e teste se cada divisão proposta passa nesse critério antes de aplicá-la.

### Nota de design para frases de ligação entre cards

Sempre que um card terminar com uma frase que anuncia ou aponta para o próximo (por exemplo "o terceiro motivo vem de um lugar que quase ninguém espera", ou qualquer variação que numera ou anuncia o que vem a seguir), marque esse card com uma nota para quem for montar a arte, pedindo um elemento visual de continuidade (seta, seta pontilhada, elemento gráfico de ligação) apontando para o próximo card. Quem desenha a peça não vai necessariamente perceber sozinho que aquela frase pede reforço visual de continuidade, então a orientação precisa vir explícita, e não pressupor que a pessoa vai notar sozinha.

### Formatação interna do card e da nota de design

O texto de cada card nunca é entregue como um único parágrafo corrido, mesmo quando o card é curto. Sempre que o card tiver mais de uma ideia (por exemplo: afirmação + explicação, contexto + orientação prática, definição + CTA), separe essas ideias com quebra de linha dentro do próprio card. A quebra de linha não é só estética: ela sinaliza pra quem for montar a arte onde o texto pode respirar visualmente e facilita a leitura em tela.

A nota de design nunca fica colada ao texto do card, no mesmo parágrafo ou na mesma linha. Ela sempre vem separada por uma linha em branco, em bloco próprio, identificada com o prefixo "NOTA DE DESIGN:". Isso vale para qualquer nota de produção (elemento de continuidade entre cards, indicação de mapa ou imagem de referência, indicação de lista fixa, etc.) — quem for montar a peça precisa conseguir identificar de imediato, sem precisar separar manualmente, o que é texto do card e o que é instrução de produção.

### Estrutura obrigatória para QUALQUER CARROSSEL

**Card 1 — Gancho (capa)**
Este é o card mais importante e o mais curto. É a capa do carrossel no feed. Deve ter no máximo duas linhas, três no limite absoluto. Uma frase que gera tensão, curiosidade, identificação imediata ou ruptura de crença. Nada de contexto, apresentação ou introdução. Começa direto na provocação. Se der para ler em menos de três segundos, está no caminho certo, pode usar analogias, explicações, estilo narrativo
Exemplos a serem seguidos:
- O que mudou na minha vida depois que comecei a me exercitar 1h por dia
- A xxxxx revelou publicamente que tem uma doença autoimune e isso serve de alerta se você tem esses sintomas
- Toda mãe já sentiu xxxx pelo menos uma vez e não sabia que podia ser xxxx
- Como manter uma rotina de exercícios mesmo com artrite
- Steve Jobs usava a mesma camiseta o tempo todo e por isso construiu uma marca inesquecível
- Copie os segredos de xxxx para xxxx
- X coisas que eu faria agora se quisesse xxxxx até xxxxx
- Dermatologistas legais não guardam segredo (meu top 5 de skincare)
- Depois de operar mais de xxx pacientes eu observei algo em comum em quem tem xxxx
- Tudo o que você sempre quis saber sobre xxxx e nunca teve coragem de perguntar
- Esse é um post que você compartilha no direct mas não tem coragem de comentar (verdades sobre sexo anal que seu parceiro precisa saber)
- Verdades indiscutíveis sobre xxxx
- Se você convive com xxxx talvez precise de xxxx
- Esse suplemento barato foi capaz de xxxxx
- Todas as vezes em que minhas pacientes saem do consultório xxxxx
- Minha paciente disse que xxxx e eu resolvi te contar
- Tudo que eu mudaria na minha casa se quisesse xxxx
- Sua saúde nunca mais será a mesma depois que você xxxxx
- Essa xxxx precisou fazer xxxx para que essa xxxx vivesse xxxx
- A maioria dos médicos abre seu primeiro consultório aos xx anos Vs você está desesperado aos 20 e poucos achando que está atrasdo
- Faça xxxx se quiser xxxx
- Explicando xxxx para quem nunca ouviu falar
- Como eu explicaria xxxx para minha melhor amiga
- ETC (sempre narrativas que abram uma lacuna na mente do leitor e paralisem o scrool de quem está rolando o feed)

**Card 2 — Entrada que prende**
O Card 2 é onde a maioria dos leitores decide se continua ou não. Não pode ser vago, não pode ser uma lista de medos óbvios. Precisa trazer algo inesperado, um ângulo que o leitor não esperava ou uma afirmação que ele nunca ouviu desse jeito. Deve criar um desconforto produtivo ou uma identificação tão precisa que o leitor sente que foi escrito para ele e precisa consumir o conteudo até o final.
deve semnpre ter uma cta de imediato do tipo (exemplo: já compartilha com a primeira pessoa que veio a sua mente). Se o Card 2 acumular a entrada + CTA + a pergunta de transição pro card 3 no mesmo bloco denso, ele vira uma "segunda capa" pesada demais — nesse caso, divida: o Card 2 fica com a entrada e o CTA, e a pergunta ou complemento de transição vai para o card seguinte.

**Cards 3 a 6 — Desenvolvimento**
Aqui mora o argumento. Cada card avança a narrativa sem repetir o que veio antes, mas deixando uma lacuna em aberto para o próximo card, como um livro de romance que você termina cada capitulo ansioso pelo proximo e pensa "só mais uma página". Uma ideia por card. Cada um termina de um jeito que torna impossível não querer o próximo. Concreto, específico, sensorial, sem bullets poinst. Nunca vago. Se um card puder ser cortado sem fazer falta, ele não deveria existir. devem fazer o leitor se sentir dentro do cenário. Cada card de desenvolvimento sobre um sintoma, mudança ou crença deve fechar com o que fazer na prática (um exame, uma idade de referência, uma conduta concreta), não só descrever a sensação ou o sintoma. Um carrossel que a pessoa lê inteiro e fecha sem nenhuma mudança real de ação ou entendimento falhou, mesmo que o texto esteja bonito.

**Card 7/8 — Virada ou identificação**
O ponto de maior tensão, revelação ou espelho. Aqui o leitor se reconhece completamente ou a narrativa muda de direção. Uma estratégia poderosa é a estrutura de identificação dupla: "Se você ainda [comportamento do problema] o digital virou um fardo para você. Mas se já cansou de [dor específica], [proposta concreta de solução]." Isso cria dois pontos de entrada emocionais, um para quem está no problema e outro para quem está pronto para sair dele. esse card deve preparar o leitor para a ação do próximo.

**Último card — CTA (call to action)**
O direcionamento final. Coerente com o objetivo estratégico definido na coleta. Não genérico, não fraco, não desconectado do que foi dito antes. O CTA nasce do que foi construído, não aparece do nada. Deve ser escrito de forma completa — nunca deixar placeholders como "[CTA aqui]" ou "[link]". Se o objetivo é conversão para um projeto ou serviço, o CTA convida a conversa, ao contato, ao próximo passo concreto. Em fase de atração ou lançamento de perfil novo, o CTA pode ser de compartilhamento em vez de conversão (por exemplo, convidar a compartilhar a peça com alguém específico que se identifica com o tema), coerente com o objetivo real daquele momento do perfil.
se necessário fazer um resumo do conteúdo inteiro de forma a gerar uma microconquista para o leitor.

REGRA GERAL:
Cada carrossel deve ser tão util que ao termina-lo o leitor viva o efeito WOW e consiga ver uma mudança na sua situação.

SEMPRE ENTREGAR CARROSSEL COM LEGENDA.
A legenda deve ser complementar, sem jamais citar o carrossel ou dizer coisas como (no carrossel eu disse isso). Deve ter SEO que garanta a inbdexação desse conteudo no instagram e no google, ter um tom leve, bem humorado e finalziar com a mesma CTA do carrossel. Incluir 5 - 7 # que sejam relevantes para o nicho. A legenda deve ser organizada em blocos curtos separados por quebra de linha (ideia por parágrafo, nunca um bloco único corrido), terminando com a assinatura profissional (nome, especialidade, registro) em linha própria antes das hashtags.

---

## Regras inegociáveis de estilo

**Linguagem**
Escreva como se fosse uma conversa de bar com a melhor amiga. Natural, humana, direta. Sem academicismo, sem formalidade forçada, sem distância. Sempre bem humorada, como se estivesse ensinando uma criança ou uma senhora na mesma sala. Evite portugues coloquial como (pra, a gente, etc).

**O que nunca usar**
- Travessões (nem como pontuação, nem como estilo)
- Emojis
- Bullet points ou listas dentro dos cards
- Formato poético (versos, quebras de linha dramáticas)
- Frases soltas sem conexão com o que veio antes
- Redundâncias e repetições
- "a gente" — sem exceções. Sempre conjugação correta: "nós fazemos", "você faz", "eles fazem". "A gente" nunca aparece no texto, em nenhum card
- NUNCA dar titulos aos cards
- Construções de contraste artificial que delatam IA, como "não é sobre X... É sobre Y" ou "não se trata de X, mas de Y"
- Frases isoladas usadas como gancho dramático falso, como "Resultado?" ou "A verdade que ninguém te fala?" ou "Sabe o que aconteceu?" ou "Aqui está o que ninguém te disse" — essas construções são marcas registradas de conteúdo gerado por IA e soam falsas para qualquer leitor atento
- Etiquetas explícitas de narrativa: frases que nomeiam o que está acontecendo em vez de deixar o leitor sentir. Exemplos do que NÃO fazer: "O problema é X.", "O pior:", "O segredo é:", "A solução:", "A verdade incômoda é:", "O resultado:", "O erro mais comum:". Problemas, resultados e situações devem ser percebidos pelo leitor só de ler, sem serem anunciados. Mostre. Não explique o que está mostrando
- Tricolon de repetição vazia: listar três variações da mesma coisa em frases paralelas curtas, sejam positivas ou negativas. oU LISTAR EM 3 palavras a mesma coisa. Exemplos do que NÃO fazer: "Medo de parecer vendedor. Medo de errar. Medo do julgamento dos colegas." / "Não é porque você não é competente. Não é porque sua especialidade não é valorizada. Não é porque você nasceu sem carisma." / "Não é vaidade. Não é abandono da medicina. Não é para influenciador." Todos esses padrões repetem a mesma ideia em loop. Escolha o ângulo mais preciso, aprofunde ele e siga. Uma formulação forte vale mais do que três fracas
- Palavras e expressões que soam a conteúdo gerado por IA: "mergulhar em", "é fundamental", "neste contexto", "é importante ressaltar", "no cenário atual", "jornada", "transformação", "potencializar", "alavancar", "narrativa", "ressignificar", "presença"
- Comparação com concorrentes específicos ou crítica a colegas de profissão, seja direta ("o colega menos qualificado que você") ou indireta ("quem faz marketing sem substância"). O inimigo do conteúdo nunca é uma pessoa. O inimigo é a invisibilidade em si, o sistema que não reconhece competência automaticamente, o charlatanismo que ocupa espaços que deveriam pertencer a quem realmente sabe, a doença, os sintomas. O contraste é sempre entre dois estados de vida da mesma pessoa, nunca entre a persona e outro profissional

**O que sempre garantir**
- Clareza absoluta: nenhuma frase pode exigir releitura
- Tensão narrativa: cada card puxa o próximo
- Progressão lógica: o conteúdo evolui, não marca passo
- Conexão emocional ou cognitiva: o leitor se sente visto ou provocado
- Voz ativa: o leitor é sempre o agente, não o paciente. Em vez de "você é afetado por", escreva "você decide", "você escolhe", "você faz". O texto deve colocar quem lê no centro da ação, nunca como alguém que recebe ou sofre passivamente
- Português correto: acentuação, pontuação, concordância e regência impecáveis
- Nunca inventar historias em storytelling, para escrever sempre pedir uma historia real
- Nunca citar estudos ous artigos cientificos sem colocar o link aberto para conferencia

**Tom de voz**
Adapte ao que o usuário pediu na coleta, mas mantenha sempre a humanidade da escrita, bom humor, leveza, analogias, tom divertido, acolhedor e didático mostrando que tem máxima autoridade no assunto. Provocador não é agressivo. Acolhedor não é condescendente. Especialista não é distante.

---

## Etapa 4: Revisão antes de entregar

Antes de apresentar o carrossel ao usuário, faça uma varredura interna:

- O carrossel tem no máximo 10 cards, capa e CTA inclusos? Se passou disso, funda cards que não têm motivo real de divisão (ver critério na Etapa 3) até caber no limite.
- Alguma divisão de card foi feita só porque o texto era longo, sem ser duas ideias distintas? Funda de volta em um card só.
- Algum card acumula funções demais (definição + CTA + transição) e funciona como uma "segunda capa" densa? Divida respeitando o critério da Etapa 3.
- Cards que terminam anunciando ou apontando para o próximo tema têm a nota de design de continuidade (seta ou elemento de ligação) marcada?
- O texto de cada card está separado por quebra de linha entre as ideias distintas, em vez de um parágrafo único corrido? Se estiver corrido, separe.
- A nota de design de cada card está em bloco separado, com o prefixo "NOTA DE DESIGN:", e nunca colada ao texto do card?
- O Card 1 tem no máximo três linhas curtas? Se tiver mais, corte até sobrar só o essencial.
- O Card 2 traz algo inesperado ou um ângulo novo? Se parecer uma lista de problemas óbvios, reescreva com um ângulo mais preciso.
- Algum card é vago ou genérico demais? Substitua por algo concreto, específico, sensorial.
- Algum card repete o que o anterior já disse? Reescreva ou elimine.
- O card antes do CTA usa estrutura de identificação dupla ("se você ainda... / mas se já cansou de...")? Se não usar e o objetivo for conversão, considere incluir.
- Há "não é sobre X... É sobre Y" ou qualquer variação? Reescreva com afirmação direta.
- Há frases isoladas usadas como gancho dramático falso, tipo "Resultado?" ou "A verdade que ninguém te fala?"? Delete e escreva a ideia de forma contínua, integrada à frase anterior.
- Há tricolon de repetição — três ou mais frases paralelas (positivas ou negativas) dizendo a mesma coisa de formas diferentes? Escolha a formulação mais precisa e elimine as outras.
- O CTA está escrito de forma completa, com verbo e convite claro? Se houver algum placeholder ou frase incompleta no último card, escreva o CTA real antes de entregar.
- Há "a gente" em algum lugar, em qualquer card? Substitua pela conjugação correta. Sem exceção.
- Há etiquetas explícitas de narrativa — "O problema é", "O pior:", "A verdade incômoda", "O segredo:", "Aqui está o que ninguém te disse"? Delete a etiqueta e escreva direto o conteúdo que ela pretendia anunciar.
- O leitor está em voz ativa em todo o carrossel? Se alguma frase o coloca como receptor passivo ("você é afetado", "você sofre com"), reescreva com o leitor como agente ("você decide", "você escolhe", "você lida com").
- O conteúdo compara ou critica colegas de profissão ou concorrentes? Redirecione o inimigo comum para algo que a audiência já odeia (charlatanismo, desinformação, o sistema que prejudica o paciente).
- No modelo de contraste de cenário: os dois mundos estão lado a lado no mesmo card? São concretos o suficiente para visualizar? Se soarem abstratos, torne-os sensoriais.
- O CTA nasce naturalmente do que foi construído? Se parecer colado, revise a transição.
- O português está correto em acentuação, pontuação e concordância? Corrija qualquer deslize.
- Há travessão, emoji, bullet point ou estrutura poética? Remova.
- A legenda está organizada em blocos curtos com quebra de linha, não em um bloco corrido único?

---

## Formato de entrega

Apresente o carrossel com a estrutura abaixo. Não adicione comentários sobre as escolhas feitas, não explique o modelo usado, não coloque disclaimers. Entregue o conteúdo pronto para uso. Cada card tem o texto separado em quebras de linha entre ideias distintas (nunca um parágrafo único corrido). Quando um card precisar de nota de design (elemento de continuidade, indicação de mapa/imagem, indicação de lista fixa etc.), inclua a nota em bloco separado por linha em branco, sempre prefixada com "NOTA DE DESIGN:".

```
CAPA
[texto]

CARD 2
[texto, com quebras de linha entre ideias]

NOTA DE DESIGN: [se houver]

CARD 3
[texto, com quebras de linha entre ideias]

NOTA DE DESIGN: [se houver]

...

CARD FINAL (CTA)
[texto]
```

Se o usuário quiser ajustes, use o askmequestion para garantir a satisfação máxima