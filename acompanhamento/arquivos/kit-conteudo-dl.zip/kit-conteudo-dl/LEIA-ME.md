# Kit de conteudo DL Estudio

Tres receitas que o Claude passa a seguir sozinho quando voce pedir conteudo:

- **carrossel**: monta o carrossel do zero, escolhendo o modelo certo para o tema.
- **reels**: escreve o roteiro de video curto, com gancho nos primeiros segundos.
- **youtube**: escreve o roteiro de video longo, com titulo, descricao e os cortes.

## Como instalar
1. Nao abra nem descompacte este arquivo.
2. No aplicativo do Claude, abra Cowork e depois Plugins.
3. Clique em adicionar, no canto de cima, e escolha Enviar plugin.
4. Escolha este arquivo.

Depois de instalado, e so pedir: "monta um carrossel sobre X" ou "escreve o roteiro de um Reels sobre X".
Ele le o seu cerebro e o seu design system antes de escrever.

Dani Lemos // DL Estudio
