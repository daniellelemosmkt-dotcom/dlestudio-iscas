# Como funciona o meu trabalho

## A minha semana
- Toda segunda: conteúdo da semana aprovado.
- Todo dia 1: números do mês (consultas, faturamento, avaliações no Google).
- Avaliação nova no Google: resposta sugerida para eu aprovar, sem citar dado do paciente.

## Onde fica cada coisa
- **Arquivos:** [ex.: Drive › Clientes › nome do cliente]
- **Tarefas:** [Trello, Notion, lista no Drive]
- **Agenda:** [Google Agenda]
- **Ferramentas que eu uso:** Drive, agenda do Google, WhatsApp (só para mim), Instagram

## Passo a passo que se repete
> Escreva aqui as tarefas que você faz sempre do mesmo jeito. Cada uma pode virar um funcionário.

1. [tarefa] › [como você faz]
