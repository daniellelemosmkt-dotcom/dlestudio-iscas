# O que eu vendo

> Um bloco por serviço. Quanto mais claro, melhor ele responde orçamento e dúvida.

## [Nome do serviço]
- **O que inclui:** [lista]
- **O que não inclui:** [lista]
- **Preço ou faixa:** [opcional]
- **Prazo / duração:** [ex.: 1 hora, 30 dias, por mês]
- **Como contratar:** [link, WhatsApp, agenda]

## Perguntas que mais chegam
- [pergunta] › [a sua resposta]

---
**Exemplo (Saúde):** Consulta de nutrição (1h) com plano alimentar e retorno em 30 dias. Acompanhamento de 3 meses. Não inclui: exames.
