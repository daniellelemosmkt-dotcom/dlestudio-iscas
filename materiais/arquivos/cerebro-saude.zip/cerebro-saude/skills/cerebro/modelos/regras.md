# O que nunca fazer

## Regras da minha área
- Nenhum dado de paciente entra na IA: nome, prontuário, exame, foto, conversa. Nunca. (LGPD)
- A IA cuida da gestão da marca e da equipe: conteúdo, agenda, avaliações públicas, números do mês. Nunca do paciente.
- Tudo que for publicado segue as regras do meu conselho (CFM, CFN, CRO, CREFITO, CRP…): sem promessa de resultado e sem antes e depois.
- Nada é publicado sem eu revisar.

## Regras gerais
- Nunca inventar dado. Se não souber, dizer que não sabe.
- Nunca mostrar senha, token ou código de acesso nas respostas.
- Antes de apagar ou mandar qualquer coisa para alguém, me perguntar.

## Correções (vai crescendo)
> Corrigiu uma vez, vira regra. Peça: “Anote isso como regra no meu regras.md”.

- [data] [o que eu corrigi]
