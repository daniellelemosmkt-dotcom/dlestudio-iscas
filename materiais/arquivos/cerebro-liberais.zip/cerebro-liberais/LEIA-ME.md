# Plugin Cérebro · Liberais

Os 6 documentos que fazem o Claude te conhecer. Você preenche uma vez e ele lê sempre.

## Jeito 1: instalar como plugin (Cowork)
1. Baixe o arquivo **cerebro-liberais.zip**.
2. No app do Claude, abra **Cowork › Plugins › Enviar plugin** e escolha o zip.
3. Abra o seu projeto “Meu funcionário” e peça: **“Monta o meu cérebro”**. Ele te entrevista e cria a pasta `cerebro/`.

## Jeito 2: só os arquivos
1. Copie a pasta `skills/cerebro/modelos/` para dentro da pasta do seu projeto e renomeie para **cerebro**.
2. Preencha os arquivos (ou peça a entrevista com o prompt da aula).
3. No Projeto do claude.ai, você também pode subir os 6 arquivos em **Conhecimento do projeto**.

## Os arquivos
- **quem-sou.md:** quem você é e como quer ser vista
- **servicos.md:** o que você vende, o que inclui e o que não inclui
- **publico.md:** para quem você trabalha, nas palavras dela
- **voz.md:** como você fala, com 3 mensagens reais suas
- **regras.md:** o que nunca fazer, e as correções que você for fazendo
- **processos.md:** como funciona a sua semana e onde fica cada coisa

Imersão Modo Automático · Dani Lemos (@daanylemos)
