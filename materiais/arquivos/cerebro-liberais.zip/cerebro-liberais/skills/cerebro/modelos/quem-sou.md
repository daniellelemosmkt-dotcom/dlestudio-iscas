# Quem eu sou

> Preencha com as suas palavras. Pode ser em tópicos. O Claude lê este arquivo antes de qualquer tarefa.

- **Nome:** [seu nome]
- **O que eu faço:** [ex.: advogada]
- **Há quanto tempo:** [anos]
- **Onde eu atendo:** [cidade, online, presencial]
- **Quem trabalha comigo:** [sozinha, sócia, secretária, equipe]

## A minha história em 3 linhas
[como você chegou até aqui]

## O que me diferencia
[o que as suas clientes dizem que só você faz]

## Como eu quero ser vista
[3 palavras. Ex.: próxima, organizada, sem enrolação]

---
**Exemplo (Liberais):** Sou advogada de família há 9 anos, em Belo Horizonte. Atendo presencial e online. Tenho uma estagiária.
