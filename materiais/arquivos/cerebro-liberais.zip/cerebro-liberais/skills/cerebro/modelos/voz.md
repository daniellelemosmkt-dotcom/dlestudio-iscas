# Como eu falo

- **Tom:** [ex.: acolhedora e direta, sem formalidade]
- **Trato por:** [você / senhora / pelo nome]
- **Emojis:** [sim, poucos / não]
- **Palavras que eu uso:** [lista]
- **Palavras que eu nunca uso:** [lista]

## 3 mensagens reais minhas
> Cole aqui 3 mensagens que você mandou para clientes e gostou. É o jeito mais rápido de ele pegar o seu tom.

1. [mensagem]
2. [mensagem]
3. [mensagem]

---
**Exemplo (Liberais):** “Oi, Paula! Recebi os documentos. Vou analisar até sexta e te mando por aqui o que falta, combinado?” (troque pelo seu jeito)
