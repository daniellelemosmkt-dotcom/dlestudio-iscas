# Para quem eu trabalho

- **Quem é:** [idade, profissão, momento de vida]
- **O que tira o sono dela:** [as dores, nas palavras dela]
- **O que ela quer:** [o resultado que ela deseja]
- **O que faz ela travar antes de comprar:** [objeções]
- **Palavras que ela usa:** [como ela fala do problema]

## Quem eu não atendo
[perfil que não é para você]

---
**Exemplo (Liberais):** Mulheres de 30 a 50 anos passando por separação, que querem entender os direitos sem briga e sem juridiquês.
