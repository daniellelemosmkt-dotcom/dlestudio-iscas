# Como funciona o meu trabalho

## A minha semana
- Cliente novo: primeira conversa › proposta › contrato › pasta do caso.
- Toda sexta: conferir prazos da semana seguinte.
- Retorno para quem pediu orçamento em até 2 dias.

## Onde fica cada coisa
- **Arquivos:** [ex.: Drive › Clientes › nome do cliente]
- **Tarefas:** [Trello, Notion, lista no Drive]
- **Agenda:** [Google Agenda]
- **Ferramentas que eu uso:** Drive, agenda do Google, WhatsApp, planilha de prazos

## Passo a passo que se repete
> Escreva aqui as tarefas que você faz sempre do mesmo jeito. Cada uma pode virar um funcionário.

1. [tarefa] › [como você faz]
