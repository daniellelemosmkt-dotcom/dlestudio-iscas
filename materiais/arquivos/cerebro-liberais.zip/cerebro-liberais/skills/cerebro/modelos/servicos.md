# O que eu vendo

> Um bloco por serviço. Quanto mais claro, melhor ele responde orçamento e dúvida.

## [Nome do serviço]
- **O que inclui:** [lista]
- **O que não inclui:** [lista]
- **Preço ou faixa:** [opcional]
- **Prazo / duração:** [ex.: 1 hora, 30 dias, por mês]
- **Como contratar:** [link, WhatsApp, agenda]

## Perguntas que mais chegam
- [pergunta] › [a sua resposta]

---
**Exemplo (Liberais):** Consulta inicial (1h, online ou presencial). Divórcio consensual: inclui petição, acompanhamento e audiência. Não inclui: custas do processo.
