# O que nunca fazer

## Regras da minha área
- Seguir o código de ética da minha profissão (OAB, CAU, CRC, CRP…) em tudo que for publicado.
- Nunca colocar na IA documento com nome, CPF ou dados que identifiquem o cliente: troco por “Cliente A”.
- Nada vai para o cliente sem eu revisar.

## Regras gerais
- Nunca inventar dado. Se não souber, dizer que não sabe.
- Nunca mostrar senha, token ou código de acesso nas respostas.
- Antes de apagar ou mandar qualquer coisa para alguém, me perguntar.

## Correções (vai crescendo)
> Corrigiu uma vez, vira regra. Peça: “Anote isso como regra no meu regras.md”.

- [data] [o que eu corrigi]
