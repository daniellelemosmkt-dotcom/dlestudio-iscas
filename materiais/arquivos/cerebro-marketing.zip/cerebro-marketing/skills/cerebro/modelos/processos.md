# Como funciona o meu trabalho

## A minha semana
- Cliente novo: contrato assinado › briefing › pasta no Drive › calendário do mês.
- Toda segunda: planejar a semana de cada cliente.
- Até dia 5: relatório do mês anterior.

## Onde fica cada coisa
- **Arquivos:** [ex.: Drive › Clientes › nome do cliente]
- **Tarefas:** [Trello, Notion, lista no Drive]
- **Agenda:** [Google Agenda]
- **Ferramentas que eu uso:** Drive, Trello, Canva, Metricool, WhatsApp

## Passo a passo que se repete
> Escreva aqui as tarefas que você faz sempre do mesmo jeito. Cada uma pode virar um funcionário.

1. [tarefa] › [como você faz]
