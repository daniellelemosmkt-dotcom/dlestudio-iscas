# O que nunca fazer

## Regras da minha área
- Nada vai para o cliente sem eu aprovar.
- Nunca prometer número de seguidores ou de vendas.
- Arte e legenda seguem a identidade de cada cliente (está na ficha dele).

## Regras gerais
- Nunca inventar dado. Se não souber, dizer que não sabe.
- Nunca mostrar senha, token ou código de acesso nas respostas.
- Antes de apagar ou mandar qualquer coisa para alguém, me perguntar.

## Correções (vai crescendo)
> Corrigiu uma vez, vira regra. Peça: “Anote isso como regra no meu regras.md”.

- [data] [o que eu corrigi]
