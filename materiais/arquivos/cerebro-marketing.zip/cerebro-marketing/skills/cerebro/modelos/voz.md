# Como eu falo

- **Tom:** [ex.: acolhedora e direta, sem formalidade]
- **Trato por:** [você / senhora / pelo nome]
- **Emojis:** [sim, poucos / não]
- **Palavras que eu uso:** [lista]
- **Palavras que eu nunca uso:** [lista]

## 3 mensagens reais minhas
> Cole aqui 3 mensagens que você mandou para clientes e gostou. É o jeito mais rápido de ele pegar o seu tom.

1. [mensagem]
2. [mensagem]
3. [mensagem]

---
**Exemplo (Marketing):** “Oi, Carla! Os posts da semana já estão na pasta para você aprovar. Se puder olhar até quinta, já deixo tudo agendado.” (troque pelo seu jeito)
