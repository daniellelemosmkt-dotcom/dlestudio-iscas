/* MINHA MARCA
   As cores, as fontes e o jeito de falar. É daqui que o Claude tira o tom de tudo o que ele escreve.
   Peça assim: "Monta a minha marca comigo, uma pergunta por vez." */

window.DADOS.marca = {

  // Suas cores. { nome: "", hex: "#000000", onde: "" }
  // "onde" é para que serve: fundo, texto, destaque, botão.
  cores: [],

  // Suas fontes.
  fontes: {
    titulo: "",
    texto: ""
  },

  // Como você fala.
  tomDeVoz: {
    comoFalo: "",
    palavrasQueUso: [],
    palavrasQueNuncaUso: [],
    comoNuncaFalo: ""
  },

  // Marcas e perfis que você gosta de olhar, e o que você gosta em cada um.
  // { referencia: "", oQueGosto: "" }
  referencias: [],

  // O que não pode acontecer na sua arte nem no seu texto.
  oQueNaoPode: [],

  // Onde ficam os seus arquivos de marca no computador: logo, fontes, fotos.
  // { oQue: "", caminho: "" }
  arquivos: []
};
