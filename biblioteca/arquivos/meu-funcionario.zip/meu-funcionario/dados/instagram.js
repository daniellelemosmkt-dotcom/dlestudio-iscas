/* MEU INSTAGRAM
   O seu perfil como ele está hoje, o crescimento e o diagnóstico do Claude.
   Hoje você preenche conversando. Quando o conector estiver ligado, ele puxa tudo sozinho.
   Peça assim: "Olha o meu Instagram e preenche o meu perfil aqui." */

window.DADOS.instagram = {

  perfil: {
    usuario: "",        // o @ , sem a arroba
    nome: "",           // o nome que aparece em negrito
    bio: "",            // a bio inteira, com as quebras de linha
    link: "",           // o link da bio
    foto: "",           // caminho de uma imagem na pasta, ou endereço na internet
    seguidores: 0,
    seguindo: 0,
    publicacoes: 0
  },

  // Os destaques, na ordem em que aparecem.
  // { nome: "", capa: "" }
  destaques: [],

  // Os últimos posts, do mais novo para o mais antigo. A tela monta a grade de três em três.
  // {
  //   tipo: "foto",     foto, carrossel, reel
  //   capa: "",         caminho da imagem
  //   legenda: "",
  //   data: "",         AAAA-MM-DD
  //   curtidas: 0,
  //   comentarios: 0,
  //   alcance: 0
  // }
  grade: [],

  // Um ponto por medição. O gráfico usa esta lista.
  // { data: "AAAA-MM-DD", seguidores: 0 }
  crescimento: [],

  // O que o Claude viu no seu perfil. Ele escreve isto, você não.
  diagnostico: {
    emUmaFrase: "",
    oQueEstaBom: [],
    oQueEstaAtrapalhando: [],
    oQueFazerAgora: [],      // no máximo três coisas, na ordem
    atualizadoEm: ""         // AAAA-MM-DD
  }
};
