/* MEUS RESULTADOS
   O dinheiro. Esta tela lê os seus leads e soma o que fechou, o que está em negociação e o que foi perdido.
   O que você preenche aqui é só o que não dá para calcular a partir dos leads.
   Peça assim: "Atualiza os meus resultados." */

window.DADOS.resultados = {

  // Quanto você quer faturar por mês, em reais.
  metaMensal: 0,

  // O que entra todo mês sem você vender de novo: contrato, mensalidade, assinatura.
  // { cliente: "", valor: 0, desde: "AAAA-MM-DD", venceEm: "AAAA-MM-DD", oQueEntrego: "" }
  recorrente: [],

  // Fechamentos de meses anteriores, para o gráfico ter história.
  // { mes: "AAAA-MM", faturado: 0, fechados: 0, perdidos: 0 }
  meses: [],

  // O que o Claude percebeu olhando os seus números. Ele escreve.
  leitura: {
    emUmaFrase: "",
    oQueMudar: [],
    atualizadoEm: ""
  }
};
