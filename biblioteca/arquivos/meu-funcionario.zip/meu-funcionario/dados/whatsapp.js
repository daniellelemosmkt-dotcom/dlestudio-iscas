/* MEU WHATSAPP
   O que chegou no seu WhatsApp e ainda está esperando você.
   Quem preenche é o seu funcionário, depois que a uazapi estiver ligada.
   Ele lê pelo arquivo whatsapp.json desta pasta, que é onde mora a sua chave.
   Peça assim: "Olha o meu WhatsApp e atualiza o sistema."

   A CHAVE NUNCA ENTRA AQUI. Este arquivo guarda só o que apareceu na tela. */

window.DADOS.whatsapp = {

  // Fica true depois que a ligação funcionar.
  ligado: false,

  // Só os quatro últimos números, para você conferir que é o número certo.
  // Nunca o número inteiro, nunca o token.
  finalDoNumero: "",

  // Quando ele olhou pela última vez. AAAA-MM-DD HH:MM
  olhadoEm: "",

  // Quem está esperando resposta sua.
  // {
  //   quem: "",        só o primeiro nome
  //   oQuePediu: "",   em uma frase, com as suas palavras
  //   esperaOQue: "",  o que a pessoa espera que você faça
  //   quando: "",      AAAA-MM-DD da última mensagem dela
  //   urgencia: "alta" alta, media, baixa
  // }
  // Saúde e advocacia: só o primeiro nome, nunca diagnóstico e nunca dado de processo.
  esperando: [],

  // O que você prometeu para alguém e ainda não entregou.
  // { paraQuem: "", oQuePrometi: "", ate: "" }
  prometido: [],

  // Os seus grupos, só para você saber o que ele enxerga.
  // { nome: "", pessoas: 0 }
  grupos: [],

  // As rotinas que já estão programadas.
  // { rotina: "", quando: "", ligada: true }
  // Exemplos de rotina: bom dia, plantão, fechamento do dia, arrumação da semana.
  rotinas: []
};
