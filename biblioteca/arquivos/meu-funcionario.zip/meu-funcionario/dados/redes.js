/* MINHAS REDES
   As redes que você usa de verdade. Cadastre só essas.
   Peça assim: "Cadastra as minhas redes sociais comigo." */

window.DADOS.redes = {

  // As redes que existem para escolher. A tela mostra todas, e marca as que você ativou.
  disponiveis: ["instagram", "facebook", "tiktok", "linkedin", "youtube"],

  // Uma entrada por rede que você usa.
  // {
  //   rede: "instagram",   uma das de cima
  //   usuario: "",         o @ , sem a arroba
  //   link: "",            o endereço do perfil
  //   bio: "",             a bio como ela está hoje, copiada
  //   foto: "",            caminho de uma imagem na pasta, ou endereço na internet
  //   seguidores: 0,
  //   principal: false,    marque true na rede que mais importa para você
  //   ativa: true
  // }
  minhas: []
};
