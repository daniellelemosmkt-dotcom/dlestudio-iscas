/* MEU NEGÓCIO
   Quem você atende, o que você vende e como você vende.
   Quem preenche: o Claude, conversando com você. Você não precisa escrever nada aqui na mão.
   Peça assim: "Preenche o meu negócio comigo, uma pergunta por vez." */

window.DADOS.negocio = {

  // O nome do seu negócio, ou o seu nome se você trabalha sozinha.
  nome: "",

  // Uma frase dizendo o que você faz, do jeito que você falaria para uma pessoa no elevador.
  oQueFaz: "",

  // Para quem você trabalha. Um item por tipo de cliente.
  // { quem: "", oQuePrecisa: "", ondeEstá: "" }
  publico: [],

  // Os problemas que você resolve, na fala do cliente, não na sua.
  problemasQueResolve: [],

  // O que você vende hoje.
  // { nome: "", oQueEntrega: "", preco: "", prazo: "" }
  ofertas: [],

  // Como a venda acontece hoje, do primeiro contato até o sim.
  comoVende: "",

  // O que o cliente diz quando não compra, e o que você responde.
  // { objecao: "", resposta: "" }
  objecoesComuns: [],

  // Suas decisões de venda: o que você aceita e o que você não aceita.
  // Exemplo de regra, não de conteúdo: prazo mínimo, forma de pagamento, tipo de cliente que você recusa.
  regrasDeVenda: [],

  // O que você não faz, por mais que peçam.
  oQueNaoFaz: []
};
