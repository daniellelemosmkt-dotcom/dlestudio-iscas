/* MEU PLANEJAMENTO
   A sua meta, o prazo, e as ações que levam até lá.
   Quem monta a estratégia é o Claude, a partir da sua meta e do seu negócio.
   Peça assim: "Monta o meu planejamento a partir da minha meta." */

window.DADOS.planejamento = {

  meta: {
    oQue: "",        // o que você quer alcançar, em uma frase
    numero: "",      // o número que diz que você chegou lá
    ate: "",         // AAAA-MM-DD
    porQue: ""       // o que muda na sua vida quando isso acontecer
  },

  // Como o Claude pretende chegar lá. Ele escreve.
  estrategia: "",

  // As ações. Separe bem o que é dele e o que é seu.
  // {
  //   acao: "",
  //   quemFaz: "claude",   claude, voce, ou juntas
  //   porQue: "",          o que essa ação move na meta
  //   prazo: "",           AAAA-MM-DD
  //   status: "aberta"     aberta, fazendo, feita
  // }
  acoes: [],

  // Os tipos de post que entram no seu calendário, e para que serve cada um.
  // { tipo: "", paraQue: "", quantosPorSemana: 0 }
  tiposDePost: [],

  // Materiais de graça que você usa para atrair gente.
  // { isca: "", paraQuem: "", oQuePromete: "", onde: "" }
  iscas: [],

  // O que trava enquanto você não decidir.
  // { oQue: "", decisaoQueFalta: "" }
  esperandoVoce: []
};
