/* MEUS CONTEÚDOS PARA APROVAR
   O que o Claude preparou e está esperando o seu sim.
   Regra da casa: todo conteúdo tem que vir com o motivo de existir. Sem isso, não entra na grade.
   Peça assim: "Escreve os conteúdos desta semana e põe para eu aprovar." */

window.DADOS.conteudos = {

  // {
  //   id: "",
  //   titulo: "",            como você reconhece esse conteúdo na grade
  //   tipo: "copy",          copy, estatico, carrossel, reel
  //   data: "",              AAAA-MM-DD em que ele vai ao ar
  //   status: "esperando",   esperando, aprovado, recusado, publicado
  //   legenda: "",           a legenda inteira
  //   arquivos: [],          caminhos das imagens, na ordem. Carrossel: uma por card. Vazio: só texto
  //   video: "",             caminho do vídeo, se for reel
  //
  //   porQueEstrategico: "", o que esse conteúdo faz pela sua meta
  //   objetivo: "",          o que você quer que a pessoa faça depois de ver
  //   paraQuem: "",          qual público seu
  //
  //   oQueEuAchei: ""        o que você respondeu quando recusou
  // }
  itens: []
};
