/* MEU DIA
   As tarefas e os compromissos. Quando a agenda estiver ligada, o Claude traz os compromissos sozinho.
   Peça assim: "Monta o meu dia de hoje." */

window.DADOS.dia = {

  // { o: "", quando: "AAAA-MM-DD", status: "aberta", quemPediu: "", quanto: "" }
  // status: aberta, fazendo, feita
  // quanto: quanto tempo você acha que leva, em palavras suas
  tarefas: [],

  // { titulo: "", dia: "AAAA-MM-DD", hora: "00:00", onde: "", comQuem: "" }
  agenda: [],

  // O que o seu funcionário fez enquanto você não estava olhando.
  // É aqui que você confere se ele está trabalhando direito.
  // { quando: "AAAA-MM-DD HH:MM", oQue: "", onde: "" }
  oQueOFuncionarioFez: []
};
