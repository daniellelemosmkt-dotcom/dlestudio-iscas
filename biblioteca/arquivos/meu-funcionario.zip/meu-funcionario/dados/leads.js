/* MEUS LEADS
   Cada pessoa que demonstrou interesse, e em que pé está a conversa.
   Hoje você preenche conversando com o Claude. Quando o WhatsApp e o Instagram estiverem ligados,
   ele mesmo traz as pessoas novas para cá.
   Peça assim: "Cadastra um lead novo comigo." */

window.DADOS.leads = {

  // As colunas do quadro, na ordem. Mexa aqui só se o seu funil for diferente.
  colunas: [
    { id: "novo",       nome: "Chegou agora" },
    { id: "conversa",   nome: "Conversando" },
    { id: "proposta",   nome: "Proposta enviada" },
    { id: "fechado",    nome: "Fechou" },
    { id: "perdido",    nome: "Não foi" }
  ],

  // As fichas.
  // {
  //   id: "",              número ou texto, só não pode repetir
  //   nome: "",
  //   contato: "",         WhatsApp, @ do Instagram ou e-mail
  //   origem: "",          de onde veio: indicação, Instagram, anúncio, site
  //   interesse: "",       o que essa pessoa quer
  //   valor: 0,            quanto vale essa venda, em reais
  //   coluna: "novo",      o id de uma das colunas acima
  //   ultimoContato: "",   AAAA-MM-DD
  //   proximoPasso: "",    o que VOCÊ tem que fazer, não o que ela tem
  //   quando: "",          AAAA-MM-DD do próximo passo
  //   notas: ""
  // }
  fichas: []
};
