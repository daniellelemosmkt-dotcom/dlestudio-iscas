/* MEU CÉREBRO
   As suas ideias, e o que você já ensinou ao Claude.
   Peça assim: "Guarda esta ideia no meu cérebro." */

window.DADOS.cerebro = {

  // Ideia solta, do jeito que veio. Não precisa estar pronta.
  // { ideia: "", quando: "AAAA-MM-DD", viraOQue: "", status: "guardada" }
  // viraOQue: post, isca, produto, processo, nada ainda
  // status: guardada, fazendo, virou, descartada
  ideias: [],

  // O que você aprendeu e não quer esquecer.
  // { oQue: "", porQueImporta: "" }
  aprendizados: [],

  // Os plugins que você instalou.
  // { nome: "", deOndeVeio: "", paraQueServe: "", instaladoEm: "AAAA-MM-DD", uso: "" }
  // uso: todo dia, às vezes, instalei e não uso
  plugins: [],

  // As skills avulsas que você ligou.
  // { nome: "", paraQueServe: "", deOndeVeio: "" }
  skills: [],

  // Os conectores ligados, e o que cada um deixa o Claude ver.
  // { conector: "", oQueEleVe: "", ligadoEm: "AAAA-MM-DD" }
  conectores: [],

  // O que você mesma criou: plugin, skill ou rotina.
  // { nome: "", oQueFaz: "", criadoEm: "AAAA-MM-DD" }
  oQueEuCriei: []
};
