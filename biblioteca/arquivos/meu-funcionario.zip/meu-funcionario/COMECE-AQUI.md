# Meu Funcionário

O seu sistema. Ele começa vazio e vai enchendo conforme você conversa com o Claude.

## Em três passos

**1. Guarde a pasta onde você vai achar.**
Pode ser em Documentos. O nome da pasta pode ser `meu-funcionario` mesmo.

**2. Abra o arquivo `index.html`.**
Dois cliques. Ele abre no seu navegador. Vai estar vazio, e cada tela diz o que fazer para encher.

**3. Abra o Claude, vá na aba Code, aponte para esta pasta e cole isto:**

```
Você é o meu funcionário e esta pasta é o nosso sistema. Vamos começar pelo começo: me conhecer.

Faça assim:
1. Leia o arquivo CLAUDE.md desta pasta antes de qualquer coisa.
2. Me faça UMA pergunta por vez, curta, em português simples, e espere a minha resposta antes da próxima. Comece por: o que eu faço, para quem, o que eu vendo e quanto custa, como a venda acontece hoje, e o que eu nunca faço.
3. A cada resposta minha, escreva você o texto no meu lugar, com as minhas palavras, e me mostre para eu dizer sim ou corrigir.
4. Quando terminarmos, grave tudo em dados/negocio.js, respeitando os campos que já estão lá, e me avise para eu recarregar a tela.

Não me deixe nada para preencher sozinha. Se faltar informação, pergunte, não invente. Nunca escreva senha, chave ou token em nenhum arquivo.
```

Quando ele avisar, volte no navegador e aperte F5. A tela estará preenchida.

## O que tem dentro

| Tela | Para que serve |
|---|---|
| **Hoje** | O que está esperando por você agora. Ela se monta sozinha a partir das outras |
| **Meus leads** | Cada pessoa interessada, em quadro, da primeira conversa até o sim |
| **Meus resultados** | O dinheiro, somado a partir dos leads. Você não digita nada duas vezes |
| **Minhas redes** | As redes que você usa, como elas estão hoje |
| **Meu Instagram** | O seu perfil, o crescimento e o diagnóstico do Claude |
| **Meu planejamento** | A sua meta, e as ações que levam até ela |
| **Conteúdos para aprovar** | O que ele preparou, com o motivo de existir em cada um |
| **Meu dia** | Tarefas e compromissos |
| **Meu negócio** | Quem você atende e o que você vende. A base de tudo |
| **Minha marca** | Cores, fontes e o seu jeito de falar |
| **Meu cérebro** | As suas ideias, e tudo o que você já instalou |

## A ordem que funciona

Preencha **Meu negócio** primeiro, depois **Minha marca**. São essas duas que fazem o resto deixar de
ser genérico. Tudo o que ele escrever antes disso vai ser chute bonito.

## Onde ficam os seus dados

Na pasta `dados/`, em arquivos de texto comuns. Nada vai para a internet. Se você quiser guardar uma
cópia segura, peça ao Claude para pôr esta pasta num repositório **privado** do GitHub.

## Quando alguma coisa quebrar

Cole isto no Claude:

```
A tela do Meu Funcionário deu erro. Confere os arquivos da pasta dados, acha o que está escrito errado e conserta. Depois me diga em uma frase o que estava acontecendo.
```

## O que vem nas próximas semanas

- **Semana 2:** conectores. O Instagram e a agenda passam a encher as telas sozinhos.
- **Semana 3:** o WhatsApp. Lead novo entra no quadro sem você digitar.
- **Semana 4:** banco de dados e link próprio. O sistema sai do seu computador e vai para a internet,
  só seu.
